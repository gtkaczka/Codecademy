package com.techelevator.tenmo.dao;

public interface TransferStatusDao {

    boolean isSend(int id);

}
