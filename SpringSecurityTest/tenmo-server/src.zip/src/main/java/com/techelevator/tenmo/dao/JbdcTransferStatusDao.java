package com.techelevator.tenmo.dao;

import org.springframework.stereotype.Component;

@Component
public class JbdcTransferStatusDao implements TransferStatusDao {

    public boolean isSend(int id){
        boolean sending = false;
        if(id == 2){
           sending = true;
        }
        return sending;
    }

}
