package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.model.BuildingAccount;

import java.util.List;

public interface BuildingAccountDao {

    public List<BuildingAccount> getAllAccounts();

}
