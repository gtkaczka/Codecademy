package com.techelevator.tenmo.dao;

public interface TransferTypeDao {
}
