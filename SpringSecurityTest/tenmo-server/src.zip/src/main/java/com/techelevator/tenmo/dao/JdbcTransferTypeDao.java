package com.techelevator.tenmo.dao;

import org.springframework.stereotype.Component;

@Component
public class JdbcTransferTypeDao implements TransferTypeDao {
}
