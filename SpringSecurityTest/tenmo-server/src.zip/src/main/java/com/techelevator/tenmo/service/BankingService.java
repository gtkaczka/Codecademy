package com.techelevator.tenmo.service;

import com.techelevator.tenmo.dao.*;
import com.techelevator.tenmo.model.Transfer;

import java.math.BigDecimal;
import java.security.Principal;

public class BankingService {

    private AccountDao accountDao;
    private TransferDao transferDao;
    private TransferStatusDao transferStatusDao;
    private TransferTypeDao transferTypeDao;
    private UserDao userDao;

    public BankingService(AccountDao accountDao, TransferDao transferDao, TransferStatusDao transferStatusDao, TransferTypeDao transferTypeDao, UserDao userDao) {
        this.accountDao = accountDao;
        this.transferDao = transferDao;
        this.transferStatusDao = transferStatusDao;
        this.transferTypeDao = transferTypeDao;
        this.userDao = userDao;
    }

   /* public void sendMoney(BigDecimal amount, Principal principal, int id){
        int ownerId = userDao.principalUserId(principal);
        BigDecimal d = new BigDecimal(0);
        BigDecimal ownerBalance = accountDao.getBalance(ownerId);
        if(ownerBalance.compareTo(amount) >= 0 && amount.compareTo(d) > 0){
            transferDao.transferTo(amount, id);
            transferDao.transferFrom(amount, ownerId);
        } else {
            System.out.println("Sorry your amount doesn't work.");
        }

    }*/

}
